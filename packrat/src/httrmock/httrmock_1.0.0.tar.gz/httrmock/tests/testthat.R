library(testthat)
library(httrmock)

test_check("httrmock")
